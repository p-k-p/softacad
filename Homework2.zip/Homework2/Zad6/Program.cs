﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad6
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = -20; i <= 50; i++)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
