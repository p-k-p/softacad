﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad2
{
    public class Student
    {
        public string name;
        public string subject;
        public double grade;
        public int yearInCollege;
        public int age;
        public bool hasDegree;
        public decimal money;

        public Student()
        {
            grade = 4.0;
            yearInCollege = 1;
            hasDegree = false;
            money = 0M;
        }

        public Student(string name, string subject, int age) : this()
        {
            this.name = name;
            this.subject = subject;
            this.age = age;
        }

        public void UpYear()
        {
            if (hasDegree == false)
            {
                this.yearInCollege++;
                if (this.yearInCollege == 4)
                {
                    hasDegree = true;
                    return;
                }
            } else
            {
                Console.WriteLine("The Student already has a degree!");
                return;
            }
                    
        }

        public decimal ReceiveScholarship(double min, decimal amount)
        {
            if (this.grade >= min && this.age < 30)
            {
              return this.money += amount;
            } else
            {
                return this.money;
            }
        }
    }
}
